package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import db.JdbcUtil;

public class BoardDAO_pn {
	Connection con;
	PreparedStatement pstmt, pstmt2;
	ResultSet rs;
	
	// 글쓰기
	public int write(BoardBean_pn board) {
		int insertCount = 0;
		int num = 1;
		
		try {
			con = JdbcUtil.getConnection();
			String sql = "SELECT MAX(num) FROM pn";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				num = rs.getInt(1) + 1;
			}
			
			sql = "INSERT INTO pn VALUES (?,?,?,?,?,now(),0)";
			pstmt2 = con.prepareStatement(sql);
			pstmt2.setInt(1, num);
			pstmt2.setString(2, board.getName());
			pstmt2.setString(3, board.getPass());
			pstmt2.setString(4, board.getSubject());
			pstmt2.setString(5, board.getContent());
			
			insertCount = pstmt2.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("구문 오류 - write()");
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
			JdbcUtil.close(pstmt2);
			JdbcUtil.close(con);

		}
		
		return insertCount;
	}
	
	// 게시물 조회
	public ArrayList<BoardBean_pn> writecheck(int pageNum, int listLimit) {
		ArrayList<BoardBean_pn> list = null;
		
		try {
			con = JdbcUtil.getConnection();
			int startRow = (pageNum - 1) * listLimit;
			String sql = "SELECT * FROM pn ORDER BY num DESC LIMIT ?,?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, listLimit);
			
			rs = pstmt.executeQuery();
			
			list = new ArrayList<BoardBean_pn>();
			
			while(rs.next()) {
				BoardBean_pn board = new BoardBean_pn();
				board.setNum(rs.getInt("num"));
				board.setName(rs.getString("name"));
				board.setPass(rs.getString("pass"));
				board.setSubject(rs.getString("subject"));
				board.setContent(rs.getString("content"));
				board.setDate(rs.getDate("date"));
				board.setReadcount(rs.getInt("readcount"));
				
				list.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("구문 오류 - writecheck()");
		} finally {
			JdbcUtil.close(con);
			JdbcUtil.close(pstmt);
			JdbcUtil.close(rs);

		}
		
		return list;
	}
	
	// 전체 게시물 목록 갯수를 조회
		public int selectListCount() {
			int listCount = 0;
			
			try {
				con = JdbcUtil.getConnection();
				
				String sql = "SELECT COUNT(num) FROM pn";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					listCount = rs.getInt(1);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - selectListCount()");
			} finally {
				JdbcUtil.close(rs);
				JdbcUtil.close(pstmt);
				JdbcUtil.close(con);
			}
			
			return listCount;
		}
	
		// 게시물 상세 내용 조회
		public BoardBean_pn selectBoard(int num) {
			BoardBean_pn board = null;
			
			try {
				con = JdbcUtil.getConnection();
				
				String sql = "SELECT * FROM pn WHERE num=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					board = new BoardBean_pn();
					board.setNum(rs.getInt("num"));
					board.setName(rs.getString("name"));
					board.setPass(rs.getString("pass"));
					board.setSubject(rs.getString("subject"));
					board.setContent(rs.getString("content"));
					board.setDate(rs.getDate("date"));
					board.setReadcount(rs.getInt("readcount"));
					
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - selectBoard()");
			} finally {
				JdbcUtil.close(rs);
				JdbcUtil.close(pstmt);
				JdbcUtil.close(con);
			}
			
			return board;
		}
		
		// 조회수 증가
		public void Readcount(int num) {
			try {
				con = JdbcUtil.getConnection();
				
				String sql = "UPDATE pn SET readcount=readcount+1 WHERE num=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - Readcount()");
			} finally {
				JdbcUtil.close(pstmt);
				JdbcUtil.close(con);
			}
			
		}
		
		// 게시물 수정 작업 
		public int updateBoard(BoardBean_pn board) {
			int updateCount = 0;
			
			try {
				con = JdbcUtil.getConnection();
				
				// 1. 패스워드 판별 작업
				String sql = "SELECT pass FROM pn WHERE num=?"; 
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, board.getNum());
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					if(rs.getString("pass").equals(board.getPass())) { 
						
						// 2. 수정(UPDATE) 작업
						sql = "UPDATE pn SET name=?,subject=?,content=? WHERE num=?";
						pstmt2 = con.prepareStatement(sql);
						pstmt2.setString(1, board.getName());
						pstmt2.setString(2, board.getSubject());
						pstmt2.setString(3, board.getContent());
						pstmt2.setInt(4, board.getNum());
						
						updateCount = pstmt2.executeUpdate();
					}
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - updateBoard()");
			} finally {
				JdbcUtil.close(pstmt);
				JdbcUtil.close(pstmt2);
				JdbcUtil.close(con);
			}
			
			return updateCount;
		}
		
		
		// 게시물 삭제 작업 
		public int deleteBoard(int num, String pass) {
			int deleteCount = 0;
			
			try {
				con = JdbcUtil.getConnection();
				
				String sql = "SELECT * FROM pn WHERE num=? AND pass=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				pstmt.setString(2, pass);
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					sql = "DELETE FROM pn WHERE num=?";
					pstmt2 = con.prepareStatement(sql);
					pstmt2.setInt(1, num);
					deleteCount = pstmt2.executeUpdate();
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - deleteBoard()");
			} finally {
				JdbcUtil.close(pstmt);
				JdbcUtil.close(pstmt2);
				JdbcUtil.close(con);
			}
			
			return deleteCount;
		}
		
		// 최근 게시물 5개 조회
		public ArrayList<BoardBean_pn> RecentBoardList() {
			ArrayList<BoardBean_pn> boardList = null;
			
			try {
				con = JdbcUtil.getConnection();
				
				String sql = "SELECT * FROM pn ORDER BY num DESC LIMIT ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, 5);
				
				rs = pstmt.executeQuery();
				
				boardList = new ArrayList<BoardBean_pn>();
				
				while(rs.next()) {
					
					BoardBean_pn board = new BoardBean_pn();
					
					board.setNum(rs.getInt("num"));
					board.setName(rs.getString("name"));
					board.setPass(rs.getString("pass"));
					board.setSubject(rs.getString("subject"));
					board.setContent(rs.getString("content"));
					board.setDate(rs.getDate("date"));
					board.setReadcount(rs.getInt("readcount"));
					
					boardList.add(board);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - RecentBoardList()");
			} finally {
				JdbcUtil.close(rs);
				JdbcUtil.close(pstmt);
				JdbcUtil.close(con);
			}
			
			return boardList;
		}
		
		// 검색어에 해당하는 게시물 목록 갯수 조회
		public int SearchListCount(String search, String searchType) {
			int listCount = 0;
			
			try {
				con = JdbcUtil.getConnection();
				
				String sql = "SELECT COUNT(num) FROM pn WHERE " + searchType + " LIKE ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%" + search + "%");
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					listCount = rs.getInt(1);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - SearchListCount()");
			} finally {
				JdbcUtil.close(rs);
				JdbcUtil.close(pstmt);
				JdbcUtil.close(con);
			}
			
			return listCount;
		}
		
		
		// 검색어에 해당하는 게시물 목록 조회
		public ArrayList<BoardBean_pn> SearchBoardList(int pageNum, int listLimit, String search, String searchType) {
			ArrayList<BoardBean_pn> boardList = null;
			
			try {
				con = JdbcUtil.getConnection();
				
				int startRow = (pageNum - 1) * listLimit;
				
				String sql = "SELECT * FROM pn WHERE " + searchType + " LIKE ? ORDER BY num DESC LIMIT ?,?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%" + search + "%");
				pstmt.setInt(2, startRow);
				pstmt.setInt(3, listLimit);
				
				rs = pstmt.executeQuery();
				
				boardList = new ArrayList<BoardBean_pn>();
				
				while(rs.next()) {
					BoardBean_pn board = new BoardBean_pn();
					board.setNum(rs.getInt("num"));
					board.setName(rs.getString("name"));
					board.setPass(rs.getString("pass"));
					board.setSubject(rs.getString("subject"));
					board.setContent(rs.getString("content"));
					board.setDate(rs.getDate("date"));
					board.setReadcount(rs.getInt("readcount"));
					
					boardList.add(board);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQL 구문 오류 - SearchBoardList()");
			} finally {
				JdbcUtil.close(rs);
				JdbcUtil.close(pstmt);
				JdbcUtil.close(con);
			}
			
			return boardList;
		}
		
	}
