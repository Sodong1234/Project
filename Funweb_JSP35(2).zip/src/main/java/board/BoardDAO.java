package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import db.JdbcUtil;

// static import : 특정 클래스의 static 메서드를 클래스명 없이 접근하기 위한 import
// < 기본 문법 > import static 패키지명.클래스명.메서드명; 
//			   또는 import static 패키지명.클래스명.*
//import static db.JdbcUtil.getConnection;
//import static db.JdbcUtil.close;

// => db.jdbcUtil 클래스의 모든 static 메서드를 import 하는 경우
import static db.JdbcUtil.*;

public class BoardDAO {

	Connection con = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	public int insertBoard(BoardBean board) {
		int insertCount = 0;
		int num = 1; // 새 글 번호를 저장할 변수(초기값으로 1 지정)
		con = getConnection();
		
		try {
			// 1) 새 글 번호(num) 계산
			// 현재 게시물들 중 가장 큰 번호(num) 조회하여 조회된 num 값 + 1 을 num 에 저장하고,
			// 조회 결과가 없을 경우 num 값을 새 글 번호로 사용
			String sql = "SELECT MAX(num) FROM board"; // board 테이블의 num 컬럼 중 최대값 조회
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			// rs.next() 메서드를 통해 다음 레코드 존재 여부 확인
			// => 다음 레코드가 존재하는 경우 기존 게시물이 있다는 의미이므로
			//	  조회된 값(num 의 최대값) + 1 을 num 변수에 저장
			if(rs.next()) { // 등록된 게시물이 하나라도 존재할 경우(= 최대값이 조회될 경우)
				num = rs.getInt(1) + 1;
			}
//			System.out.println("새 글 번호 : " + num);
			
			// 2. 글쓰기 작업 수행(글 번호는 num 변수값, 작성일은 now() 함수, 조회수는 0으로 설정)
			String sql2 = "INSERT INTO board VALUES (?,?,?,?,?,now(),0)";
			pstmt2 = con.prepareStatement(sql2);
			pstmt2.setInt(1, num);
			pstmt2.setString(2, board.getName());
			pstmt2.setString(3, board.getPass());
			pstmt2.setString(4, board.getSubject());
			pstmt2.setString(5, board.getContent());
			
			insertCount = pstmt2.executeUpdate();
				
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("SQL 구문 오류 - insertBoard();");
		} finally {
			// 자원 반환(static import 로 인해 JdbcUtil 클래스명 생략 가능)
			close(rs);
			close(pstmt);
			close(pstmt2);
			close(con);

		}
		return insertCount;
		
	}
	
	public ArrayList<BoardBean> selectBoardList(int pageNum, int listLimit) {
		ArrayList<BoardBean> boardList = null;
		
		con = getConnection();
		
		try {
			// 현재 페이지에서 불러올 목록(레코드)의 첫 번째(시작) 행번호 계산
			// => 시작행번호는 (페이지번호 - 1) * 목록갯수 값 사용
			//	  ex) 1페이지 = (1 - 1) * 10 = 0
			//		  2페이지 = (2 - 1) * 10 = 10
			//		  3페이지 = (3 - 1) * 10 = 20
			int startRow = (pageNum - 1) * listLimit;
			
			// board 테이블의 모든 레코드 조회(글번호(num) 기준으로 내림차순 정렬)
			// => SELECT 컬럼명 FROM 테이블명 ORDER BY 정렬할컬럼명 정렬방식;
			//	  (정렬 방식 - 오름차순 : ASC, 내림차순 : DESC)
			// => SELECT 컬럼명 FROM 테이블명 LIMIT 시작행번호,목록갯수;
			String sql = "SELECT * FROM board ORDER BY num DESC LIMIT ?,?";
			// => 목록갯수는 파라미터로 전달받은 listLimit 값 사용
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, listLimit);

			rs = pstmt.executeQuery();
			
			// 전체 레코드를 저장할 ArrayList<BoardBean> 객체 생성
			// => 주의! 반복문 시작 전에 미리 생성해야함
			boardList = new ArrayList<BoardBean>();
			// 다음레코드가 존재할 동안 반복하면서 
			// 1개 레코드 정보를 BoardBean 객체에 저장 후
			// 다시 BoardBean 객체를 전체 레코드 저장하는 ArrayList<BoardBean> 객체에 추가
			
			while(rs.next()) {
				// 1개 레코드를 저장할 BoardBean 객체 생성
				BoardBean board = new BoardBean();
				// BoardBean 객체에 조회된 1개 레코드 정보를 모두 저장
				board.setNum(rs.getInt("num"));
				board.setName(rs.getString("name"));
				board.setPass(rs.getString("pass"));
				board.setSubject(rs.getString("subject"));
				board.setContent(rs.getString("content"));
				board.setDate(rs.getDate("date"));
				board.setReadcount(rs.getInt("readcount"));
				
				// 전체 레코드를 저장하는 ArrayList 객체에 1개 레코드가 저장된 BoardBean 객체 추가
				boardList.add(board);
			}
			
			System.out.println(boardList);
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("구문 오류 - selectBoardList()");
		} finally {
			close(rs);
			close(pstmt);
			close(con);
		}
		
		return boardList;
	}
	
}
